#include<iostream>
using namespace std;

const int MAX = 30;

struct Violation {
    string date;
    string violationType;
    double fineAmount;
};

Violation violations[MAX];
int violationCount = 0;

double getFineAmount(const string& violationType) {
    if (violationType == "Speeding") {
        return 100.0;
    } else if (violationType == "Parking") {
        return 50.0;
    } else if (violationType == "Red Light") {
        return 200.0;
    } else {
        return 0.0;
    }
}

void addViolation() {
    if (violationCount >= MAX) {
        cout << "Maximum violation limit reached!" << endl;
        return;
    }

    Violation v;
    cout << "Enter Date of Violation (dd/mm/yyyy): ";
    cin >> v.date;

    int violationChoice;
    cout << "========================\n";
    cout << "Select Violation Type: " << endl;
    cout << "1. Speeding" << endl;
    cout << "2. Parking" << endl;
    cout << "3. Red Light" << endl;
    cout << "Enter your choice (1, 2, or 3): ";
    cin >> violationChoice;

    if (violationChoice == 1) {
        v.violationType = "Speeding";
    } else if (violationChoice == 2) {
        v.violationType = "Parking";
    } else if (violationChoice == 3) {
        v.violationType = "Red Light";
    } else {
        cout << "Invalid choice!" << endl;
        return;
    }

    v.fineAmount = getFineAmount(v.violationType);
    violations[violationCount] = v;
    violationCount++;
    cout << "Violation Added Successfully!" << endl;
}

void displayViolations() {
    cout << "\nViolation Records:" << endl;
    if (violationCount == 0) {
        cout << "No violations recorded yet." << endl;
        return;
    }

    for (int i = 0; i < violationCount; i++) {
        cout << "Date: " << violations[i].date
             << ", Type: " << violations[i].violationType
             << ", Fine: " << violations[i].fineAmount << endl;
    }
}

void displayTotalFines() {
    double totalFines = 0.0;
    for (int i = 0; i < violationCount; i++) {
        totalFines += violations[i].fineAmount;
    }
    cout << "\nTotal Fines Collected: " << totalFines << endl;
}

void displayViolationsByType() {
    cout << "\nViolations Grouped by Type:" << endl;

    double totalSpeedingFines = 0.0;
    double totalParkingFines = 0.0;
    double totalRedLightFines = 0.0;

    for (int i = 0; i < violationCount; i++) {
        if (violations[i].violationType == "Speeding") {
            totalSpeedingFines += violations[i].fineAmount;
        } else if (violations[i].violationType == "Parking") {
            totalParkingFines += violations[i].fineAmount;
        } else if (violations[i].violationType == "Red Light") {
            totalRedLightFines += violations[i].fineAmount;
        }
    }

    if (totalSpeedingFines > 0) cout << "Speeding Violations: Total Fine = " << totalSpeedingFines << endl;
    if (totalParkingFines > 0) cout << "Parking Violations: Total Fine = " << totalParkingFines << endl;
    if (totalRedLightFines > 0) cout << "Red Light Violations: Total Fine = " << totalRedLightFines << endl;
}

bool login() {
    string username, password;

    const string correctUsername = "Trafficadmin";
    const string correctPassword = "secure@2025";

    cout << "================\n";
    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";
    cin >> password;

    if (username == correctUsername && password == correctPassword) {
        return true;
    } else {
        cout << "Invalid username or password!" << endl;
        return false;
    }
}

int main() {

    if (!login()) {
        cout << "Access Denied!" << endl;
        return 0;
    }

    int select;

    while (true) {
        cout << "=============================\n";
        cout << "\"Traffic Violation Tracker\"" << endl;
        cout << "1. Add a Violation" << endl;
        cout << "2. Display All Violations" << endl;
        cout << "3. Display Total Fines Collected" << endl;
        cout << "4. Display Violations by Type" << endl;
        cout << "5. Exit" << endl;

        cout << "======================\n";
        cout << "Enter your selection: ";
        cin >> select;

        switch (select) {
            case 1:
                addViolation();
                break;
            case 2:
                displayViolations();
                break;
            case 3:
                displayTotalFines();
                break;
            case 4:
                displayViolationsByType();
                break;
            case 5:
                cout << "====================================\n";
                cout << "Exiting the Program.\"ThankYou\"\n" << endl;
                return 0;
            default:
                cout << "======================================\n";
                cout << "Invalid selection, please try again." << endl;
        }
    }

    return 0;
}
